<script setup>

</script>

<template>
  <div class="container-fluid d-flex flex-column align-items-center justify-content-center">
    <h4>Страница не найдена</h4>
    <router-link to='/' class="nav-link">Вернуться на главную</router-link>
  </div>
</template>

<style scoped>
  .container-fluid{
    height: calc(100vh - 156px);
  }

  .nav-link{
    color: gray;
    text-decoration: underline;
  }
</style>