<script setup>
import {onMounted, ref, watch} from "vue";
import products from "@/components/products.js";
import {useRoute} from "vue-router";
import ProductCard from "@/components/ProductCard.vue";
import PaginationComponent from "@/components/PaginationComponent.vue";

let productsList = ref([]);
const route = useRoute();

const getPage = () => {
  if(productsList.value.length > 0){
    productsList.value = [];
  }
  if(route.params.page>1){
    productsList.value.push(...products.slice((route.params.page - 1) * 10, (route.params.page - 1) * 10 + 9));
  }
  if(route.params.page==='1'){
    productsList.value.push(...products.slice(0, 10));
  }
}

onMounted(() => {
  getPage();
})

watch(()=>route.params.page, (newVal) => {
  getPage()
})

</script>

<template>
  <h4 class="page-title">Каталог товаров</h4>
  <p class="page-title">Страница {{route.params.page}}</p>
  <div class="container-fluid d-flex flex-wrap justify-content-evenly gap-3 p-4">
    <template v-for="item in productsList" :key="item.id">
      <ProductCard :id='item.id' :title='item.title' :image='item.cardImage' :price='item.price'
                   :description='item.description'/>
    </template>
  </div>
  <PaginationComponent/>
</template>

<style scoped>
.container-fluid{
  min-height: calc(100vh - 330px);
}

.page-title{
  margin: 20px;
  font-weight: bold;
}
</style>