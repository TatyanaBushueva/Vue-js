<script setup>

import NavBar from "@/components/layout/NavBar.vue";
import OfferCard from "@/components/OfferCard.vue";
</script>

<template>
  <h4 class="offers-title">Лучшие предложения этого сезона</h4>
  <div class="d-flex justify-content-evenly align-items-center flex-wrap mb-2 mb-md-0">
    <OfferCard image="/offer1.PNG" description="Три товара по цене одного"/>
    <OfferCard image="/offer2.PNG" description="Скидка 25% на выделенные катеогрии"/>
    <OfferCard image="/offer3.PNG" description="Все для отпуска"/>
  </div>
</template>

<style scoped>
.offers-title {
  text-align: center;
  margin: 20px auto;
  font-weight: normal;
}
</style>