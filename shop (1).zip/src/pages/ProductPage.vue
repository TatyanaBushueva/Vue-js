<script setup>
import {onMounted, ref} from "vue";
import {useRoute} from "vue-router";
import products from "@/components/products.js";

let product = ref({});
const route = useRoute();

//временная штука. в реальном проекте делается запрос по id
const getProductInfo = (id) => {
  for (let i=0; i<products.length; i++) {
    if(products[i].id === Number(id)){
      return products[i];
    }
  }
}

onMounted(()=>{
  product.value = getProductInfo(route.params.id)
})
</script>

<template>
<div class="container-fluid">
  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
    <div class="col">
      <img :src="product?.pageImage" alt="Фото товара" class="image-preview"/>
    </div>
    <div class="col gap-2 justify-content-center align-items-start">
      <h4>{{product?.title}}</h4>
      <p class="secondary-info">{{product?.price}} ₽</p>
      <div class="d-flex gap-1 justify-content-center">
        <p class="secondary-info">Количество: </p>
        <input type="number" class="form-control">
        <p class="secondary-info">шт</p>
      </div>
      <button class="btn btn-success">Купить</button>
    </div>
    <div class="col gap-2 justify-content-center align-items-start m-2">
      <h4>Описание товара:</h4>
      <p class="secondary-info">{{product?.description}}</p>
    </div>
  </div>
</div>
</template>

<style scoped>
.image-preview{
  margin: 20px;
  min-width: 150px;
  width: 70%;
  max-width: 400px;
  height: auto;
}

.col{
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

input{
  width: 70px;
}

.secondary-info{
  font-size: 17px;
}

.container-fluid{
  min-height: calc(100vh - 156px);
}
</style>