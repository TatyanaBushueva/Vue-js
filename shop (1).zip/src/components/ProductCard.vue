<script setup>
import {useRouter} from "vue-router";

const props = defineProps({
  id: {type: Number, required: true},
  title: {type: String, required: true},
  description: {type: String, required: true},
  price: {type: Number, required: true},
  image: {type: String, required: true}
})
const router = useRouter();
const showProduct = () => {
  router.push(`/product/${props.id}`);
}
</script>

<template>
  <div class="card">
    <img :src='props.image' alt="Изображение товара"/>
    <p class="nav-link product-title">{{ props.title }}</p>
    <div class="d-flex align-items-center justify-content-evenly">
      <p class="nav-link price">{{ props.price }} ₽</p>
      <button class="btn btn-success" @click="showProduct">Смотреть товар</button>
    </div>
  </div>
</template>

<style scoped>
.card {
  width: 250px;
  height: 350px;
}

img {
  width: 250px;
  height: auto;
}

.product-title {
  text-align: center;
  font-weight: normal;
}

.price{
  font-weight: bold;
}
</style>