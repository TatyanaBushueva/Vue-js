<script setup>
import products from "@/components/products.js";
import {useRouter, useRoute} from "vue-router";

const router = useRouter();
const route = useRoute();
const turnPage = (page) => {
  router.push({path: `/catalog/${page}`});
}
</script>

<template>
  <div class="d-flex mb-2 justify-content-center gap-2">
    <div class="page-item px-3 py-2" v-for="page in Math.ceil(products.length/10)" @click="turnPage(page)"
         :class="page === Number(route.params.page) ? 'active' : 'inactive'">
      {{ page }}
    </div>
  </div>
</template>

<style scoped>
.page-item {
  border: 2px solid black;
  border-radius: 3px;
  transition: background .2s ease-in-out;
  cursor: pointer;
}

.inactive:hover {
  background: lightblue;
}

.active {
  background: lightblue;
}
</style>