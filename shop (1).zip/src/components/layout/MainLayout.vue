<script setup>

import NavBar from "@/components/layout/NavBar.vue";
import FooterComponent from "@/components/layout/FooterComponent.vue";
</script>

<template>
  <NavBar/>
  <div class="main-container">
    <slot/>
  </div>
  <FooterComponent/>
</template>

<style scoped>
.main-container {
  min-height: calc(100vh - 176px);
}
</style>