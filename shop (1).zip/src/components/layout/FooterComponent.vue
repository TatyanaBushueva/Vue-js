<script setup>

</script>

<template>
<footer>
  <div class="container-fluid">
    <div class="d-flex flex-row align-items-center flex-wrap justify-content-evenly">
      <div class="d-flex flex-column align-items-center">
        <router-link to="/" class="nav-link">Главная</router-link>
        <router-link to="/catalog/1" class="nav-link">Каталог</router-link>
      </div>
      <div class="d-flex flex-column align-items-center">
        <div class="d-flex justify-content-center gap-1">
          <img src="/emailicon.png">
          <p class="nav-link">email@gmail.com</p>
        </div>
        <div class="d-flex justify-content-center gap-1">
          <img src="/phoneicon.svg">
          <p class="nav-link">+7 (xxx) xxx-xx-xx</p>
        </div>
      </div>
      <div class="d-flex flex-column align-items-center">
        <div class="d-flex justify-content-center gap-1">
          <img src="/spoticon.png">
          <p class="nav-link">Город, улица, дом</p>
        </div>
      </div>
    </div>
  </div>
</footer>
</template>

<style scoped>
footer{
  background-color: #bf988f;
}
.container-fluid{
  padding: 10px;
}
img{
  width: 30px;
  height: 30px;
}
</style>