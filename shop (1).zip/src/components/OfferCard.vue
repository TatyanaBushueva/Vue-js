<script setup>
const props = defineProps({
  description: {type: String, required: true},
  image: {type: String, required: true}
})
</script>

<template>
<div class="offer-card">
<img class="offer-card-img" :src="props.image" />
  <p class="offer-card-description">{{props.description}}</p>
</div>
</template>

<style scoped>
.offer-card{
  width: 250px;
  height: 150px;
}
.offer-card .offer-card-img{
  width: 250px;
  height: auto;
}
.offer-card .offer-card-description{
  width: 100%;
  text-align: center;
  font-size: 20px;
  font-weight: lighter;
}
</style>