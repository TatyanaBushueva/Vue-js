export default [
    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 1,
        title: 'Товар 1',
        description: 'Описание товара 1',
        price: 1000
    },
    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 2,
        title: 'Товар 2',
        description: 'Описание товара 2',
        price: 1000
    },
    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 3,
        title: 'Товар 3',
        description: 'Описание товара 3',
        price: 1000
    },
    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 4,
        title: 'Товар 4',
        description: 'Описание товара 4',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 5,
        title: 'Товар 5',
        description: 'Описание товара 5',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 6,
        title: 'Товар 6',
        description: 'Описание товара 6',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 7,
        title: 'Товар 7',
        description: 'Описание товара 7',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 8,
        title: 'Товар 8',
        description: 'Описание товара 8',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 9,
        title: 'Товар 9',
        description: 'Описание товара 9',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 10,
        title: 'Товар 10',
        description: 'Описание товара 10',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 11,
        title: 'Товар 11',
        description: 'Описание товара 11',
        price: 1000
    },

    {
        cardImage: '/product-image.png',
        pageImage: '/product-image.png',
        id: 12,
        title: 'Товар 12',
        description: 'Описание товара 12',
        price: 1000
    },
]