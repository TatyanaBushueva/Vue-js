<script setup>
import MainLayout from "@/components/layout/MainLayout.vue";
</script>

<template>
  <MainLayout>
    <router-view/>
  </MainLayout>
</template>

<style>
body {
  margin: 0;
}
</style>
