import HomePage from "@/pages/HomePage.vue";
import NotFoundPage from "@/pages/NotFoundPage.vue";
import {createRouter, createWebHistory} from "vue-router";
import CatalogPage from "@/pages/CatalogPage.vue";
import ProductPage from "@/pages/ProductPage.vue";

const routes = [
    {path: '/', component: HomePage, name: 'home'},
    {path: '/catalog/:page', component: CatalogPage, name: 'catalog'},
    {path: '/product/:id', component: ProductPage, name: 'product'},
    {path: '/:pathMatch(.*)*', redirect: '/404'},
    {path: '/404', component: NotFoundPage}
]

const router = createRouter({history: createWebHistory(), routes});
export default router;